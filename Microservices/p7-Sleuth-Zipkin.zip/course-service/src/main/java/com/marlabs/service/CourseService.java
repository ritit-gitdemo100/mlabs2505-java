package com.marlabs.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.marlabs.entity.Course;
import com.marlabs.repository.CourseRepository;
import com.marlabs.request.CourseRequest;
import com.marlabs.response.CourseResponse;

@Service
public class CourseService {

	Logger logger = LoggerFactory.getLogger(CourseService.class);
	
	@Autowired
	private CourseRepository courseRepository;
	
	public CourseResponse createCourse(CourseRequest courseRequest) {
		Course course = new Course();
		course.setCourseName(courseRequest.getCourseName());
		course.setCourseFees(courseRequest.getCourseFees());
		
		courseRepository.save(course);
		logger.info("Course Created....");
		return new CourseResponse(course);
	}

	public CourseResponse getById(long id) {
		logger.info("Getting Course of Id : "+id);
		Course course = courseRepository.findById(id).get();
		return new CourseResponse(course);
	}

}
