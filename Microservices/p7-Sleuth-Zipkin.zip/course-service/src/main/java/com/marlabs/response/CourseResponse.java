package com.marlabs.response;

import com.marlabs.entity.Course;

public class CourseResponse {

	private Long courseId;
	private String courseName;
	private Double courseFees;
	
	//Constructor to convert Course Entity to CourseResponse
	public CourseResponse(Course course) {
		super();
		this.courseId = course.getCourseId();
		this.courseName = course.getCourseName();
		this.courseFees = course.getCourseFees();
	}
	
	//Getters & Setters
	public Long getCourseId() {
		return courseId;
	}
	
	public void setCourseId(Long courseId) {
		this.courseId = courseId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public Double getCourseFees() {
		return courseFees;
	}
	public void setCourseFees(Double courseFees) {
		this.courseFees = courseFees;
	}
	
}
