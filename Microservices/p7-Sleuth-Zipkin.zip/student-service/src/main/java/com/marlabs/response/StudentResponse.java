package com.marlabs.response;

import com.marlabs.entity.Student;

public class StudentResponse {

	private Long studentId;
	private String firstName;
	private String lastName;
	private String email;
	
	private CourseResponse course; 
	
	//constructor
	public StudentResponse(Student student) {
		super();
		this.studentId = student.getStudentId();
		this.firstName = student.getFirstName();
		this.lastName = student.getLastName();
		this.email = student.getEmail();
	}
	
	
	//Getters & Setters
	public Long getStudentId() {
		return studentId;
	}

	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public CourseResponse getCourse() {
		return course;
	}
	public void setCourse(CourseResponse course) {
		this.course = course;
	}
	
}
