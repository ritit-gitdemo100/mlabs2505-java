package com.marlabs.feignclients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.marlabs.response.CourseResponse;

@FeignClient( value="api-gateway")
public interface CourseFeignClient {

	@GetMapping("/course-service/api/course/getbyid/{id}")
	public CourseResponse getById(@PathVariable long id);
}
