package com.rit.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rit.entity.Course;

@Repository
public interface CourseRepository extends JpaRepository<Course, Long>{

}
