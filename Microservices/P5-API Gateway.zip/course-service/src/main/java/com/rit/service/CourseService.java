package com.rit.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rit.entity.Course;
import com.rit.repository.CourseRepository;
import com.rit.request.CourseRequest;
import com.rit.response.CourseResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class CourseService {
	
	Logger logger = LoggerFactory.getLogger(CourseService.class);

	@Autowired
	private CourseRepository courseRepository;
	
	public CourseResponse createCourse(CourseRequest courseRequest) {
		Course course = new Course();
		course.setCourseName(courseRequest.getCourseName());
		course.setCourseFees(courseRequest.getCourseFees());
		courseRepository.save(course);
		return new CourseResponse(course);
	}
	
	public CourseResponse getById(long id) {
		logger.info("In getById : "+id);
		Course course = courseRepository.findById(id).get();
		return new CourseResponse(course);
	}
}




