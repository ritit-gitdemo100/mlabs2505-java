package com.rit.feignclients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.rit.response.CourseResponse;


@FeignClient(name="api-gateway")
//No longer specific to Course Service
public interface CourseFeignClient {

	@GetMapping("/course-service/api/course/getById/{id}")
	public CourseResponse getById(@PathVariable long id);
}













