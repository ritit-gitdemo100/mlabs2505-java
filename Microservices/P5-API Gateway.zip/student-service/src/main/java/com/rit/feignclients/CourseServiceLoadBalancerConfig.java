package com.rit.feignclients;

//@LoadBalancerClient(name="course-service")
public class CourseServiceLoadBalancerConfig {
//
//	@LoadBalanced
//	@Bean
//	public Feign.Builder feignBuilder(){
//		return Feign.builder();
//	}
}
