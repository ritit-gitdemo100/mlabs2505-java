package com.rit.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rit.entity.Student;
import com.rit.repository.StudentRepository;
import com.rit.request.StudentRequest;
import com.rit.response.StudentResponse;

@Service
public class StudentService {
	
	Logger logger = LoggerFactory.getLogger(StudentService.class);

	@Autowired
	private StudentRepository studentRepository;
	
	@Autowired
	private CommonService commonService ;
		
	public StudentResponse createStudent(StudentRequest studentRequest) {
		Student student = new Student();
		student.setFirstName(studentRequest.getFirstName());
		student.setLastName(studentRequest.getLastName());
		student.setEmail(studentRequest.getEmail());
		student.setCourseId(studentRequest.getCourseId());
		studentRepository.save(student);
		
		StudentResponse studentResponse = new StudentResponse(student);	
		studentResponse.setCourse(commonService.getCourseById(student.getCourseId()));
		return studentResponse;
	}
	
	public StudentResponse getById(long id) {
		logger.info("In getById : "+id);
		Student student = studentRepository.findById(id).get();

		StudentResponse studentResponse = new StudentResponse(student);
		studentResponse.setCourse(commonService.getCourseById(student.getCourseId()));
		return studentResponse;
	}

//	public CourseResponse getCourseById(long courseId) {
//		return courseFeignClient.getById(courseId);
//	}	
}









