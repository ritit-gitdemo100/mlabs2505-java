package com.rit.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rit.feignclients.CourseFeignClient;
import com.rit.response.CourseResponse;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class CommonService {

	@Autowired
	private CourseFeignClient courseFeignClient;
	
	Logger logger = LoggerFactory.getLogger(CourseFeignClient.class);
	long count = 1;
	
	@CircuitBreaker(name="courseService", fallbackMethod="fallbackGetCourseById")
	public CourseResponse getCourseById(long courseId) {
		logger.info("Count = "+count++);
		return courseFeignClient.getById(courseId);
	}
	
	public CourseResponse fallbackGetCourseById(long courseId, Throwable th) {
		logger.info("Error : "+th);
		return new CourseResponse();
	}	
}














