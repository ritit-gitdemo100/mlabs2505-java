package com.rit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients("com.rit.feignclients")
public class StudentService1Application {

	public static void main(String[] args) {
		SpringApplication.run(StudentService1Application.class, args);
		System.out.println("Hello Welcome");
	}

}
