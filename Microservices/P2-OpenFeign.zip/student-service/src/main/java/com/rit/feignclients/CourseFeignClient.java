package com.rit.feignclients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.rit.response.CourseResponse;

@FeignClient(url="${course.service.url}", 
	name="courseFeignClient", path="/api/course")
public interface CourseFeignClient {
	
	//Get the method from courseController
	//of course-service microservice
	@GetMapping("/getById/{id}")
	public CourseResponse getById(@PathVariable long id);
}













