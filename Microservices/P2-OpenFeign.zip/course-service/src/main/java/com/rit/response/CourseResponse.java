package com.rit.response;

import com.rit.entity.Course;

public class CourseResponse {
	private Long courseId;
	private String courseName;
	private Double courseFees;
	//Constructor to Convert Course Entity to Response
	public CourseResponse(Course course) {
		super();
		this.courseId = course.getCourseId();
		this.courseName = course.getCourseName();
		this.courseFees = course.getCourseFees();
	}
	//Getter & Setter
	public Long getCourseId() {
		return courseId;
	}
	public void setCourseId(Long courseId) {
		this.courseId = courseId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public Double getCourseFees() {
		return courseFees;
	}
	public void setCourseFees(Double courseFees) {
		this.courseFees = courseFees;
	}
}






