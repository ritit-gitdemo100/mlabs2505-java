package com.rit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rit.request.CourseRequest;
import com.rit.response.CourseResponse;
import com.rit.service.CourseService;

@RestController
@RequestMapping("/api/course")
@RefreshScope
public class CourseController {

	@Autowired
	private CourseService courseService;
	
	@Value("${course.test}")
	private String courseProfile;
	
	@GetMapping("/profile")
	public String getProfile() {
		return courseProfile;
	}
	
	@PostMapping("/create")
	public CourseResponse createCourse(@RequestBody CourseRequest courseRequest) {
		return courseService.createCourse(courseRequest);
	}
	
	@GetMapping("/getById/{id}")
	public CourseResponse getById(@PathVariable long id) {
		return courseService.getById(id);
	}
}








