// utils.js

// Export a simple function
export function add(a, b) {
    return a + b;
}

// You can also export other things like variables or objects
export const greeting = "Hello, World!";
